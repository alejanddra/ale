const solapa = document.querySelector(".solapa-superior");
const carta = document.querySelector(".carta-interior");

solapa.addEventListener("click", () => {
  solapa.classList.toggle("abierta");
  carta.classList.toggle("abierta");
});